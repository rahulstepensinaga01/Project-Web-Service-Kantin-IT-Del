
<?php
session_start();

// $nik = $_SESSION['nik'];
$nama_lengkap = $_SESSION['nama_lengkap'];
$nomor_hp = $_SESSION['nomor_hp'];
$email = $_SESSION['email'];
$password = $_SESSION['password'];
$role = $_SESSION['role'];
$saldo = $_SESSION['saldo'];

$id_pemesanantempatduduk = $_POST["id_pemesanantempatduduk"];
$id_tempatduduk = $_POST["id_tempatduduk"];
$nik = $_POST["nik"];
$nama_pemesan = $_POST["nama_pemesan"];
$tanggalpemesanan = $_POST["tanggalpemesanan"];
$nomor_tempatduduk = $_POST["nomor_tempatduduk"];
$status_tempatduduk = $_POST["status_tempatduduk"];

$url = "http://127.0.0.1:8130/pemesanantempatduduk/?id_pemesanantempatduduk=" . $id_pemesanantempatduduk;
$url2 = "http://127.0.0.1:8120/tempatduduk/?id_tempatduduk=" . $id_tempatduduk;

$ch2 = curl_init($url2);
# Setup request to send json via POST.
$payload2 = json_encode(array(
    'id_tempatduduk' => $id_tempatduduk,
    'nomor_tempatduduk' => $nomor_tempatduduk,
    'status_tempatduduk' => $status_tempatduduk
));
curl_setopt($ch2, CURLOPT_POSTFIELDS, $payload2);
curl_setopt($ch2, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
# Return response instead of printing.
curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
# Send request.
$result2 = curl_exec($ch2);
curl_close($ch2);

$ch = curl_init($url);
# Setup request to send json via POST.
$payload = json_encode(array(
    'id_pemesanantempatduduk' => $id_pemesanantempatduduk,
    'id_tempatduduk' => $id_tempatduduk,
    'nik' => $nik,
    'nama_pemesan' => $nama_pemesan,
    'tanggalpemesanan' => $tanggalpemesanan,
    'nomor_tempatduduk' => $nomor_tempatduduk,
    'status_tempatduduk' => $status_tempatduduk
));
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
# Return response instead of printing.
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
# Send request.
$result = curl_exec($ch);
curl_close($ch);
# Print response.
header('Location: daftarpemesananTempatduduk.php');



?>