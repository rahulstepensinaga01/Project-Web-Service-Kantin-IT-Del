<?php
session_start();
$url = "http://localhost:8110/produkkantin/";
$content = file_get_contents($url);
$myjson = json_decode($content);

if (!isset($_SESSION['logged_in'])) {
    header('location:../login.php');
} else {
    $nik = $_SESSION['nik'];
    $nama_lengkap = $_SESSION['nama_lengkap'];
    $nomor_hp = $_SESSION['nomor_hp'];
    $email = $_SESSION['email'];
    $password = $_SESSION['password'];
    $role = $_SESSION['role'];
    $saldo = $_SESSION['saldo'];
}

$tanggal_diterima = date("Y-m-d");
?>
<?php include "header.php"; ?>


<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Pengantaran Paket</h1>
    <p class="mb-4">Tambah Pengantaran Paket!</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Tambah Pengantaran Paket</h6>
        </div>
        <div class="card-body">
            <form method="post" enctype="multipart/form-data" action="tambahprosesPengantaranpaket.php">
                <div class="card-body">
                    <input type="number" class="form-control" id="id_paket" name="id_paket" hidden>
                    <div class="form-group">
                        <label for="nik">Nomor Resi Paket</label>
                        <input type="int" class="form-control" id="no_resipaket" name="no_resipaket" placeholder="Masukkan Nomor Resi Paket...">
                    </div>
                    <div class="form-group">
                        <label for="nik">NIK</label>
                        <input type="int" class="form-control" id="nik" name="nik" placeholder="Masukkan NIK Penerima...">
                    </div>
                    <div class="form-group">
                        <label for="nama_penerima">Nama Penerima</label>
                        <input type="text" class="form-control" id="nama_penerima" name="nama_penerima" placeholder="Masukkan Nama Penerima...">
                    </div>
                    <div class="form-group">
                        <label for="nama_pengirim">Nama Pengirim</label>
                        <input type="text" class="form-control" id="nama_pengirim" name="nama_pengirim" placeholder="Masukkan Nama Pengirim...">
                    </div>
                    <div class="form-group">
                        <label for="nomor_telepon_pengirim">Nomor Telepon Pengirim</label>
                        <input type="int" class="form-control" id="nomor_telepon_pengirim" name="nomor_telepon_pengirim" placeholder="Masukkan Nomor Telepon Pengirim...">
                    </div>
                    <div class="form-group">
                        <label for="nomor_telepon_penerima">Nomor Telepon Penerima</label>
                        <input type="int" class="form-control" id="nomor_telepon_penerima" name="nomor_telepon_penerima" placeholder="Masukkan Nomor Telepon Penerima...">
                    </div>
                    <div class="form-group">
                        <label for="alamat_tujuan">Alamat Tujuan</label>
                        <input type="text" class="form-control" id="alamat_tujuan" name="alamat_tujuan" placeholder="Masukkan Nomor Alamat Tujuan...">
                    </div>
                    <div class="form-group">
                        <label for="alamat_pengirim">Alamat Pengirim</label>
                        <input type="text" class="form-control" id="alamat_pengirim" name="alamat_pengirim" placeholder="Masukkan Nomor Alamat Pengirim...">
                    </div>
                    <div class="form-group">
                        <label for="berat_paket">Berat Paket</label>
                        <input type="text" class="form-control" id="berat_paket" name="berat_paket" placeholder="Masukkan Nomor Berat Paket...">
                    </div>
                    <div class="form-group">
                        <label for="tanggal_dikirim">Tanggal Dikirim</label>
                        <input type="date" class="form-control" id="tanggal_dikirim" name="tanggal_dikirim" placeholder="Masukkan Nomor Tanggal Dikirim...">
                    </div>
                    <div class="form-group">
                        <label for="tanggal_diterima">Tanggal Diterima</label>
                        <input type="text" class="form-control" id="tanggal_diterima" name="tanggal_diterima" value="<?php echo $tanggal_diterima ?>" readonly>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="pengantaranPaket.php"><button type="button" class="btn btn-secondary float-left">Kembali</button></a>
                    <button type="submit" class="btn btn-primary float-right">Tambahkan</button>
                </div>
            </form>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<?php include "footer.php"; ?>