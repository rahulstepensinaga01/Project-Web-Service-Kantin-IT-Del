
<?php
session_start();

$nik = $_SESSION['nik'];
$nama_lengkap = $_SESSION['nama_lengkap'];
$nomor_hp = $_SESSION['nomor_hp'];
$email = $_SESSION['email'];
$password = $_SESSION['password'];
$role = $_SESSION['role'];
// $saldo = $_SESSION['saldo'];

$id_topup1 = $_POST["id_topup"];
$nik1 = $_POST["nik"];
$nama_lengkap1 = $_POST["nama_lengkap"];
$nomor_hp1 = $_POST["nomor_hp"];
$email1 = $_POST["email"];
$password1 = $_POST["password"];
$role1 = $_POST["role"];
$saldo1 = $_POST["saldo"];
$saldo_topup1 = $_POST["saldo_topup"];
$tanggal_topup1 = $_POST["tanggal_topup"];
$status_topup1 = $_POST["status_topup"];

$url = "http://localhost:8210/topupsaldo/?id_topup=" . $id_topup1;
$url2 = "http://localhost:8090/pengguna/?nik=" . $nik1;

$sisa_saldo = $saldo1 + $saldo_topup1;

$ch2 = curl_init($url2);
# Setup request to send json via POST.
$payload2 = json_encode(array(
    'nik' => $nik1,
    'nama_lengkap' => $nama_lengkap1,
    'nomor_hp' => $nomor_hp1,
    'email' => $email1,
    'password' => $password1,
    'role' => $role1,
    'saldo' => $sisa_saldo
));
curl_setopt($ch2, CURLOPT_POSTFIELDS, $payload2);
curl_setopt($ch2, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
# Return response instead of printing.
curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
# Send request.
$result2 = curl_exec($ch2);
curl_close($ch2);

$ch = curl_init($url);
# Setup request to send json via POST.
$payload = json_encode(array(
    'id_topup' => $id_topup1,
    'nik' => $nik1,
    'nama_lengkap' => $nama_lengkap1,
    'nomor_hp' => $nomor_hp1,
    'email' => $email1,
    'password' => $password1,
    'role' => $role1,
    'saldo' => $saldo1,
    'saldo_topup' => $saldo_topup1,
    'tanggal_topup' => $tanggal_topup1,
    'status_topup' => $status_topup1
));
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
# Return response instead of printing.
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
# Send request.
$result = curl_exec($ch);
curl_close($ch);
# Print response.
header('Location: daftartopupSaldo.php');

?>