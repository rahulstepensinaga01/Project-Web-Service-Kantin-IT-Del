
<?php
session_start();

$nik = $_SESSION['nik'];
$nama_lengkap = $_SESSION['nama_lengkap'];
$nomor_hp = $_SESSION['nomor_hp'];
$email = $_SESSION['email'];
$password = $_SESSION['password'];
$role = $_SESSION['role'];
$saldo = $_SESSION['saldo'];

$id_pemesananruangan = $_POST["id_pemesananruangan"];
$id_ruangan = $_POST["id_ruangan"];
$nik = $_POST["nik"];
$nama_pemesan = $_POST["nama_pemesan"];
$tanggalpemesanan = $_POST["tanggalpemesanan"];
$lokasi_ruangan = $_POST["lokasi_ruangan"];
$status_ruangan = $_POST["status_ruangan"];

$url = "http://127.0.0.1:8190/pemesananruangan/?id_pemesananruangan=" . $id_pemesananruangan;
$url2 = "http://127.0.0.1:8170/ruangan/?id_ruangan=" . $id_ruangan;

$ch2 = curl_init($url2);
# Setup request to send json via POST.
$payload2 = json_encode(array(
    'id_ruangan' => $id_ruangan,
    'lokasi_ruangan' => $lokasi_ruangan,
    'status_ruangan' => $status_ruangan
));
curl_setopt($ch2, CURLOPT_POSTFIELDS, $payload2);
curl_setopt($ch2, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
# Return response instead of printing.
curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
# Send request.
$result2 = curl_exec($ch2);
curl_close($ch2);

$ch = curl_init($url);
# Setup request to send json via POST.
$payload = json_encode(array(
    'id_pemesananruangan' => $id_pemesananruangan,
    'id_ruangan' => $id_ruangan,
    'nik' => $nik,
    'nama_pemesan' => $nama_pemesan,
    'tanggalpemesanan' => $tanggalpemesanan,
    'lokasi_ruangan' => $lokasi_ruangan,
    'status_ruangan' => "Selesai Digunakan"
));
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
# Return response instead of printing.
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
# Send request.
$result = curl_exec($ch);
curl_close($ch);
# Print response.
header('Location: daftarpemesananRuangan.php');

?>