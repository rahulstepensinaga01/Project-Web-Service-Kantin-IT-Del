<?php
session_start();

if (isset($_GET["id_pemesanankantin"])) {
    $id_pemesanankantin = $_GET["id_pemesanankantin"];
    $url = "http://127.0.0.1:8180/pemesanankantin/" . $id_pemesanankantin;
    $content = file_get_contents($url);
    $myjson = json_decode($content, true);
}


if (!isset($_SESSION['logged_in'])) {
    header('location:../login.php');
} else {
    $nik = $_SESSION['nik'];
    $nama_lengkap = $_SESSION['nama_lengkap'];
    $nomor_hp = $_SESSION['nomor_hp'];
    $email = $_SESSION['email'];
    $password = $_SESSION['password'];
    $role = $_SESSION['role'];
    $saldo = $_SESSION['saldo'];
}

$total_pembayaran = $myjson["jumlah_produk"] * $myjson["harga_produk"];

?>
<?php include "header.php"; ?>

<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Kantin</h1>
    <p class="mb-4">Lakukan Pembayaran Pesanan Produk Kantin!</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Bayar Produk Kantin</h6>
        </div>
        <div class="card-body">
            <form method="post" enctype="multipart/form-data" action="bayarprosespesananKantin.php">
                <div class="card-body">
                    <input type="number" class="form-control" id="id_pemesanankantin" name="id_pemesanankantin" value="<?php echo $myjson["id_pemesanankantin"] ?>" hidden>
                    <div class="form-group">
                        <label for="nama_produk">Nik</label>
                        <input type="text" class="form-control" id="nik" name="nik" placeholder="Masukkan Nama Produk..." value="<?php echo $myjson["nik"] ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="nama_produk">Nama Pemesan</label>
                        <input type="text" class="form-control" id="nama_pemesan" name="nama_pemesan" placeholder="Masukkan Nama Pemesan..." value="<?php echo $myjson["nama_pemesan"] ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="nama_produk">Tanggal Pemesan</label>
                        <input type="text" class="form-control" id="tanggalpemesanan" name="tanggalpemesanan" placeholder="Masukkan Nama Pemesan..." value="<?php echo $myjson["tanggalpemesanan"] ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="nama_produk">Nama Produk</label>
                        <input type="text" class="form-control" id="nama_produk" name="nama_produk" placeholder="Masukkan Nama Produk..." value="<?php echo $myjson["nama_produk"] ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="harga_produk">Harga Produk</label>
                        <input type="text" class="form-control" id="harga_produk" name="harga_produk" placeholder="Masukkan Harga Produk..." value="<?php echo $myjson["harga_produk"] ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="jenis_pembayaran">Jenis Pembayaran</label>
                        <input type="text" class="form-control" id="jenis_pembayaran" name="jenis_pembayaran" placeholder="Masukkan JumlahProduk..." value="<?php echo $myjson["jenis_pembayaran"] ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="jumlah_produk">Jumlah Produk</label>
                        <input type="number" class="form-control" id="jumlah_produk" name="jumlah_produk" placeholder="Masukkan JumlahProduk..." value="<?php echo $myjson["jumlah_produk"] ?>" readonly>
                    </div>
                    <input type="text" class="form-control" id="status_pembayaran" name="status_pembayaran" placeholder="Masukkan JumlahProduk..." value="Lunas" hidden>
                    <div class="form-group">
                        <label for="total_pembayaran">Total Pembayaran</label>
                        <input type="number" class="form-control" id="total_pembayaran" name="total_pembayaran" placeholder="Masukkan JumlahProduk..." value="<?php echo $total_pembayaran ?>" readonly>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="daftarpemesananKantin.php"><button type="button" class="btn btn-secondary float-left">Kembali</button></a>
                    <button type="submit" class="btn btn-primary float-right">Lunas</button>
                </div>
            </form>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<?php include "footer.php"; ?>