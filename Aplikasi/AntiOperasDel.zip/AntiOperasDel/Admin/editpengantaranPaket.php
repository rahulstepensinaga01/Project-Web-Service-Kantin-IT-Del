<?php
session_start();

if (isset($_GET["id_paket"])) {
    $id_paket = (int) $_GET["id_paket"];
    $url = "http://127.0.0.1:8200/pengantaranpaket/" . $id_paket;
    $content = file_get_contents($url);
    $myjson = json_decode($content, true);
}

if (!isset($_SESSION['logged_in'])) {
    header('location:../login.php');
} else {
    $nik = $_SESSION['nik'];
    $nama_lengkap = $_SESSION['nama_lengkap'];
    $nomor_hp = $_SESSION['nomor_hp'];
    $email = $_SESSION['email'];
    $password = $_SESSION['password'];
    $role = $_SESSION['role'];
    $saldo = $_SESSION['saldo'];
}
?>
<?php include "header.php"; ?>

<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Pengantaran Paket</h1>
    <p class="mb-4">Edit Pengantaran Paket!</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Edit Produk Pengantaran Paket</h6>
        </div>
        <div class="card-body">
            <form method="post" enctype="multipart/form-data" action="editprosespengantaranPaket.php">
                <div class="card-body">
                    <input type="number" class="form-control" id="id_paket" name="id_paket" value="<?php echo $myjson['id_paket']; ?>" hidden>
                    <div class="form-group">
                        <label for="nik">Nomor Resi Paket</label>
                        <input type="int" class="form-control" id="no_resipaket" name="no_resipaket" value="<?php echo $myjson['no_resipaket']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="nik">NIK</label>
                        <input type="int" class="form-control" id="nik" name="nik" value="<?php echo $myjson['nik']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="nama_penerima">Nama Penerima</label>
                        <input type="text" class="form-control" id="nama_penerima" name="nama_penerima" value="<?php echo $myjson['nama_penerima']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="nama_pengirim">Nama Pengirim</label>
                        <input type="text" class="form-control" id="nama_pengirim" name="nama_pengirim" value="<?php echo $myjson['nama_pengirim']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="nomor_telepon_pengirim">Nomor Telepon Pengirim</label>
                        <input type="int" class="form-control" id="nomor_telepon_pengirim" name="nomor_telepon_pengirim" value="<?php echo $myjson['nomor_telepon_pengirim']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="nomor_telepon_penerima">Nomor Telepon Penerima</label>
                        <input type="int" class="form-control" id="nomor_telepon_penerima" name="nomor_telepon_penerima" value="<?php echo $myjson['nomor_telepon_penerima']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="alamat_tujuan">Alamat Tujuan</label>
                        <input type="text" class="form-control" id="alamat_tujuan" name="alamat_tujuan" value="<?php echo $myjson['alamat_tujuan']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="alamat_pengirim">Alamat Pengirim</label>
                        <input type="text" class="form-control" id="alamat_pengirim" name="alamat_pengirim" value="<?php echo $myjson['alamat_pengirim']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="berat_paket">Berat Paket</label>
                        <input type="text" class="form-control" id="berat_paket" name="berat_paket" value="<?php echo $myjson['berat_paket']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="tanggal_dikirim">Tanggal Dikirim</label>
                        <input type="date" class="form-control" id="tanggal_dikirim" name="tanggal_dikirim" value="<?php echo $myjson['tanggal_dikirim']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="tanggal_diterima">Tanggal Diterima</label>
                        <input type="text" class="form-control" id="tanggal_diterima" name="tanggal_diterima" value="<?php echo $myjson['tanggal_diterima']; ?>" readonly>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="pengantaranPaket.php"><button type="button" class="btn btn-secondary float-left">Kembali</button></a>
                    <button type="submit" class="btn btn-primary float-right">Edit</button>
                </div>
            </form>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<?php include "footer.php"; ?>