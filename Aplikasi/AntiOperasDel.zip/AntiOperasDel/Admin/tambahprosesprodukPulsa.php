<?php
session_start();

$nama_produk = $_POST["nama_produk"];
$harga = $_POST["harga"];

$url = "http://127.0.0.1:8140/pulsa/";

$ch = curl_init($url);
# Setup request to send json via POST.
$payload = json_encode(array(
    'nama_produk' => $nama_produk,
    'harga' => $harga
));
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
# Return response instead of printing.
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
# Send request.
$result = curl_exec($ch);
curl_close($ch);
# Print response.
header('Location: produkPulsa.php');
