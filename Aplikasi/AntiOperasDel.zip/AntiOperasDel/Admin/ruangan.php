<?php
session_start();
$url = "http://127.0.0.1:8170/ruangan";
$content = file_get_contents($url);
$myjson = json_decode($content);

if (!isset($_SESSION['logged_in'])) {
    header('location:../login.php');
} else {
    $nik = $_SESSION['nik'];
    $nama_lengkap = $_SESSION['nama_lengkap'];
    $nomor_hp = $_SESSION['nomor_hp'];
    $email = $_SESSION['email'];
    $password = $_SESSION['password'];
    $role = $_SESSION['role'];
    $saldo = $_SESSION['saldo'];
}
?>
<?php include "header.php"; ?>

<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Ruangan</h1>
    <p class="mb-4">Daftar Ruangan!</p>
    <div>
        <a href="tambahRuangan.php" class="btn btn-primary mb-3">Tambah Ruangan Baru</a>
    </div>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Daftar Ruangan "<b> Tersedia </b>"</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Lokasi Ruangan</th>
                            <th>Status Ruangan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php for ($i = 0; $i < count($myjson); $i++) {
                            if ($myjson[$i]->status_ruangan == "Tersedia") {
                                echo "<tr><td>" . $myjson[$i]->lokasi_ruangan . "</td>";
                                echo "<td>" . $myjson[$i]->status_ruangan . "</td>";
                                echo "<td> " . '<a href="hapusRuangan.php?id_ruangan=' . $myjson[$i]->id_ruangan . '"class="badge badge-danger">Hapus</a>' . "</td>";
                            }
                        } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Daftar Ruangan "<b> Sedang Digunakan </b>"</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="pertama" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Lokasi Ruangan</th>
                            <th>Status Ruangan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php for ($i = 0; $i < count($myjson); $i++) {
                            if ($myjson[$i]->status_ruangan == "Sedang Digunakan") {
                                echo "<tr><td>" . $myjson[$i]->lokasi_ruangan . "</td>";
                                echo "<td>" . $myjson[$i]->status_ruangan . "</td>";
                            }
                        } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Daftar Ruangan "<b> Menunggu Persetujuan </b>"</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="kedua" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Lokasi Ruangan</th>
                            <th>Status Ruangan</th>
                        </tr>
                    </thead>
                    <!-- <tfoot>
                        <tr>
                            <th>ID Produk</th>
                            <th>Nama Produk</th>
                            <th>Jenis Produk</th>
                            <th>Harga Produk</th>
                            <th>Aksi</th>
                        </tr>
                    </tfoot> -->
                    <tbody>

                        <?php for ($i = 0; $i < count($myjson); $i++) {
                            if ($myjson[$i]->status_ruangan == "Menunggu Approval") {
                                echo "<tr><td>" . $myjson[$i]->lokasi_ruangan . "</td>";
                                echo "<td>" . $myjson[$i]->status_ruangan . "</td>";
                            }
                        } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>


</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<?php include "footer.php"; ?>