<?php
session_start();

$lokasi_ruangan = $_POST["lokasi_ruangan"];

$url = "http://127.0.0.1:8170/ruangan/";

$ch = curl_init($url);
# Setup request to send json via POST.
$payload = json_encode(array(
    'lokasi_ruangan' => $lokasi_ruangan,
    'status_ruangan' => "Tersedia"
));
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
# Return response instead of printing.
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
# Send request.
$result = curl_exec($ch);
curl_close($ch);
# Print response.
header('Location: ruangan.php');
