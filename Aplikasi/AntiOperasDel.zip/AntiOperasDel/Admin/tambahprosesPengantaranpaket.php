<?php
session_start();

$id_paket = $_POST["id_paket"];
$no_resipaket = $_POST["no_resipaket"];
$nik = $_POST["nik"];
$nama_penerima = $_POST["nama_penerima"];
$nama_pengirim = $_POST["nama_pengirim"];
$nomor_telepon_pengirim = $_POST["nomor_telepon_pengirim"];
$nomor_telepon_penerima = $_POST["nomor_telepon_penerima"];
$alamat_tujuan = $_POST["alamat_tujuan"];
$alamat_pengirim = $_POST["alamat_pengirim"];
$berat_paket = $_POST["berat_paket"];
$tanggal_dikirim = $_POST["tanggal_dikirim"];
$tanggal_diterima = $_POST["tanggal_diterima"];

$url = "http://127.0.0.1:8200/pengantaranpaket/";

$ch = curl_init($url);
# Setup request to send json via POST.
$payload = json_encode(array(
    'id_paket' => $id_paket,
    'no_resipaket' => $no_resipaket,
    'nik' => $nik,
    'nama_penerima' => $nama_penerima,
    'nama_pengirim' => $nama_pengirim,
    'nomor_telepon_pengirim' => $nomor_telepon_pengirim,
    'nomor_telepon_penerima' => $nomor_telepon_penerima,
    'alamat_tujuan' => $alamat_tujuan,
    'alamat_pengirim' => $alamat_pengirim,
    'berat_paket' => $berat_paket,
    'tanggal_dikirim' => $tanggal_dikirim,
    'tanggal_diterima' => $tanggal_diterima,
    'status_paket' => "Belum Diambil"
));
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
# Return response instead of printing.
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
# Send request.
$result = curl_exec($ch);
curl_close($ch);
# Print response.
header('Location: pengantaranPaket.php');
