<?php
session_start();

$id_produk = $_POST["id_produk"];
$nama_produk = $_POST["nama_produk"];
$jenis_produk = $_POST["jenis_produk"];
$harga_produk = $_POST["harga_produk"];

$url = "http://localhost:8110/produkkantin/";

$ch = curl_init($url);
# Setup request to send json via POST.
$payload = json_encode(array(
    'id_produk' => $id_produk,
    'nama_produk' => $nama_produk,
    'jenis_produk' => $jenis_produk,
    'harga_produk' => $harga_produk
));
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
# Return response instead of printing.
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
# Send request.
$result = curl_exec($ch);
curl_close($ch);
# Print response.
header('Location: produkKantin.php');
