<?php
session_start();

$email = $_POST["email"];
$password = $_POST["password"];
$url = "http://localhost:8090/pengguna";


$curl = curl_init($url);
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

//for debug only!
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

$resp = curl_exec($curl);
curl_close($curl);
$myjson = json_decode($resp);

if (isset($_POST['email']) && isset($_POST['password'])) {
    for ($i = 0; $i < count($myjson); $i++) {
        if ($myjson[$i]->email == $email && $myjson[$i]->role == "Pengguna" && $myjson[$i]->password == $password) {
            $success = TRUE;
            $_SESSION['nik'] = $myjson[$i]->nik;
            $_SESSION['nama_lengkap'] = $myjson[$i]->nama_lengkap;
            $_SESSION['nomor_hp'] = $myjson[$i]->nomor_hp;
            $_SESSION['email'] = $myjson[$i]->email;
            $_SESSION['password'] = $myjson[$i]->password;
            $_SESSION['role'] = $myjson[$i]->role;
            $_SESSION['saldo'] = $myjson[$i]->saldo;
            $_SESSION['logged_in'] = TRUE;
            header('location:Pengguna/indexPengguna.php');
            break;
        } elseif ($myjson[$i]->email == $email && $myjson[$i]->role == "Admin" && $password == $password) {
            $success = TRUE;
            $_SESSION['nik'] = $myjson[$i]->nik;
            $_SESSION['nama_lengkap'] = $myjson[$i]->nama_lengkap;
            $_SESSION['nomor_hp'] = $myjson[$i]->nomor_hp;
            $_SESSION['email'] = $myjson[$i]->email;
            $_SESSION['password'] = $myjson[$i]->password;
            $_SESSION['role'] = $myjson[$i]->role;
            $_SESSION['saldo'] = $myjson[$i]->saldo;
            $_SESSION['logged_in'] = TRUE;
            header('location:Admin/indexAdmin.php');
            break;
        } else {
            $success = FALSE;
            header('location:login.php');
        }
    }
} else {
    echo "Harap isi semua kolom yang tersedia";
}
