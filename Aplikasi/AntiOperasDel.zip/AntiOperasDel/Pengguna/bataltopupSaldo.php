<?php
if (isset($_GET["id_topup"])) {
    $id_topup = $_GET["id_topup"];
    $url = "http://127.0.0.1:8210/topupsaldo/" . $id_topup;
    $content = file_get_contents($url);
    $myjson = json_decode($content, true);


    $ch = curl_init($url);
    # Setup request to send json via POST.
    $payload = json_encode(array('id_topup' => $id_topup));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
    # Return response instead of printing.
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    # Send request.
    $result = curl_exec($ch);
    curl_close($ch);
    # Print response.
    header('Location: daftartopupSaldo.php');
}
