<?php
session_start();
$url = "http://127.0.0.1:8190/pemesananruangan";
$content = file_get_contents($url);
$myjson = json_decode($content);

if (!isset($_SESSION['logged_in'])) {
    header('location:../login.php');
} else {
    $nik = $_SESSION['nik'];
    $nama_lengkap = $_SESSION['nama_lengkap'];
    $nomor_hp = $_SESSION['nomor_hp'];
    $email = $_SESSION['email'];
    $password = $_SESSION['password'];
    $role = $_SESSION['role'];
    $saldo = $_SESSION['saldo'];
}
?>
<?php include "header.php"; ?>

<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Ruangan</h1>
    <p class="mb-4">Daftar Pemesanan Ruangan!</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Daftar Histori Pemesanan Ruangan <b>" Menunggu Persetujuan "</b></h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Tanggal Pemesanan</th>
                            <th>NIK</th>
                            <th>Nama Pemesan</th>
                            <th>Lokasi Ruangan</th>
                            <th>Status Ruangan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php for ($i = 0; $i < count($myjson); $i++) {
                            if ($myjson[$i]->nik == $nik && $myjson[$i]->status_ruangan == "Menunggu Approval") {
                                echo "<tr><td>" . $myjson[$i]->tanggalpemesanan . "</td>";
                                echo "<td>" . $myjson[$i]->nik . "</td>";
                                echo "<td>" . $myjson[$i]->nama_pemesan . "</td>";
                                echo "<td>" . $myjson[$i]->lokasi_ruangan . "</td>";
                                echo "<td>" . $myjson[$i]->status_ruangan . "</td>";
                                echo "<td> " . '<a href="batalpesananRuangan.php?id_pemesananruangan=' . $myjson[$i]->id_pemesananruangan . '"class="badge badge-danger">Batal</a>' . "</td>";
                            }
                        } ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Daftar Histori Pemesanan Ruangan <b>" Sedang Digunakan "</b></h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="pertama" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Tanggal Pemesanan</th>
                            <th>NIK</th>
                            <th>Nama Pemesan</th>
                            <th>Lokasi Ruangan</th>
                            <th>Status Ruangan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php for ($i = 0; $i < count($myjson); $i++) {
                            if ($myjson[$i]->nik == $nik && $myjson[$i]->status_ruangan == "Sedang Digunakan") {
                                echo "<tr><td>" . $myjson[$i]->tanggalpemesanan . "</td>";
                                echo "<td>" . $myjson[$i]->nik . "</td>";
                                echo "<td>" . $myjson[$i]->nama_pemesan . "</td>";
                                echo "<td>" . $myjson[$i]->lokasi_ruangan . "</td>";
                                echo "<td>" . $myjson[$i]->status_ruangan . "</td>";
                                echo "<td> " . '<a href="selesaigunakanRuangan.php?id_pemesananruangan=' . $myjson[$i]->id_pemesananruangan . '"class="badge badge-success">Selesai Digunakan</a>' . "</td>";
                            }
                        } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Daftar Histori Pemesanan Ruangan <b>" Selesai Digunakan "</b></h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="pertama" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Tanggal Pemesanan</th>
                            <th>NIK</th>
                            <th>Nama Pemesan</th>
                            <th>Lokasi Ruangan</th>
                            <th>Status Ruangan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php for ($i = 0; $i < count($myjson); $i++) {
                            if ($myjson[$i]->nik == $nik && $myjson[$i]->status_ruangan == "Selesai Digunakan") {
                                echo "<tr><td>" . $myjson[$i]->tanggalpemesanan . "</td>";
                                echo "<td>" . $myjson[$i]->nik . "</td>";
                                echo "<td>" . $myjson[$i]->nama_pemesan . "</td>";
                                echo "<td>" . $myjson[$i]->lokasi_ruangan . "</td>";
                                echo "<td>" . $myjson[$i]->status_ruangan . "</td>";
                            }
                        } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<?php include "footer.php"; ?>