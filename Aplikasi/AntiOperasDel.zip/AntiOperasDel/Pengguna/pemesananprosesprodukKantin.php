
<?php
session_start();

$id_pemesanankantin = $_POST["id_pemesanankantin"];
$nik = $_POST["nik"];
$nama_pemesan = $_POST["nama_pemesan"];
$tanggalpemesanan = $_POST["tanggalpemesanan"];
$nama_produk = $_POST["nama_produk"];
$harga_produk = $_POST["harga_produk"];
$jenis_pembayaran = $_POST["jenis_pembayaran"];
$jumlah_produk = $_POST["jumlah_produk"];


$url = "http://localhost:8180/pemesanankantin/";

$ch = curl_init($url);
# Setup request to send json via POST.
$payload = json_encode(array(
    'id_pemesanankantin' => $id_pemesanankantin,
    'nik' => $nik,
    'nama_pemesan' => $nama_pemesan,
    'tanggalpemesanan' => $tanggalpemesanan,
    'nama_produk' => $nama_produk,
    'harga_produk' => $harga_produk,
    'jumlah_produk' => $jumlah_produk,
    'jenis_pembayaran' => $jenis_pembayaran,
    'status_pembayaran' => "Belum Lunas"
));
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
# Return response instead of printing.
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
# Send request.
$result = curl_exec($ch);
curl_close($ch);
# Print response.
header('Location: daftarpemesananKantin.php');

?>