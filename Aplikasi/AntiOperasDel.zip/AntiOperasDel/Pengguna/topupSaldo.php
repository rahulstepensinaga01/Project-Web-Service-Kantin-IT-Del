<?php
session_start();
$url = "http://localhost:8090/pengguna/";
$content = file_get_contents($url);
$myjson = json_decode($content);

if (!isset($_SESSION['logged_in'])) {
    header('location:../login.php');
} else {
    $nik = $_SESSION['nik'];
    $nama_lengkap = $_SESSION['nama_lengkap'];
    $nomor_hp = $_SESSION['nomor_hp'];
    $email = $_SESSION['email'];
    $password = $_SESSION['password'];
    $role = $_SESSION['role'];
    $saldo = $_SESSION['saldo'];
}
$tanggalpemesanan = date("Y-m-d");
for ($i = 0; $i < count($myjson); $i++) {
    if ($myjson[$i]->nik == $nik) {
        $nik1 = $myjson[$i]->nik;
        $nama_lengkap1 = $myjson[$i]->nama_lengkap;
        $nomor_hp1 = $myjson[$i]->nomor_hp;
        $email1 = $myjson[$i]->email;
        $role1 = $myjson[$i]->role;
        $saldo1 = $myjson[$i]->saldo;
        break;
    }
}
?>
<?php include "header.php"; ?>

<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Data Diri</h1>
    <p class="mb-4">Top Up Saldo!</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 ">
            <h6 class="m-0 font-weight-bold text-primary ">Top Up Saldo</h6>
            <a href="daftartopupSaldo.php"><button type="button" class="btn btn-primary float-right">Daftar Histori Top Up Saldo</button></a>
        </div>
        <div class="card-body">
            <div class="col-lg-6 mb-4">
                <a href="topupSaldo50.php">
                    <div class="card bg-danger text-white shadow">
                        <div class="card-body">
                            Top Up
                            <div class="text-white-50 small">Rp50000</div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-6 mb-4">
                <a href="topupSaldo100.php">
                    <div class="card bg-warning text-white shadow">
                        <div class="card-body">
                            Top Up
                            <div class="text-white-50 small">Rp100000</div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-6 mb-4">
                <a href="topupSaldo150.php">
                    <div class="card bg-success text-white shadow">
                        <div class="card-body">
                            Top Up
                            <div class="text-white-50 small">Rp150000</div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-6 mb-4">
                <a href="topupSaldo200.php">
                    <div class="card bg-primary text-white shadow">
                        <div class="card-body">
                            Top Up
                            <div class="text-white-50 small">Rp200000</div>
                        </div>
                    </div>
                </a>
            </div>
        </div>
        <div class=" card-footer">
            <a href="profil.php"><button type="button" class="btn btn-secondary float-left">Kembali</button></a>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<?php include "footer.php"; ?>