
<?php
session_start();

$nik = $_SESSION['nik'];
$nama_lengkap = $_SESSION['nama_lengkap'];
$nomor_hp = $_SESSION['nomor_hp'];
$email = $_SESSION['email'];
$password = $_SESSION['password'];
$role = $_SESSION['role'];
$saldo = $_SESSION['saldo'];

$id_pemesanankoperasi = $_POST["id_pemesanankoperasi"];
$nik = $_POST["nik"];
$nama_pemesan = $_POST["nama_pemesan"];
$tanggalpemesanan = $_POST["tanggalpemesanan"];
$nama_produk = $_POST["nama_produk"];
$harga_produk = $_POST["harga_produk"];
$jenis_pembayaran = $_POST["jenis_pembayaran"];
$jumlah_produk = $_POST["jumlah_produk"];
$status_pembayaran = $_POST["status_pembayaran"];

$total_pembayaran = $_POST["total_pembayaran"];

$url = "http://127.0.0.1:8160/pemesanankoperasi/?id_pemesanankoperasi=" . $id_pemesanankoperasi;
$url2 = "http://localhost:8090/pengguna/?nik=" . $nik;

if ($saldo > $total_pembayaran) {
    $sisa_saldo = $saldo - $total_pembayaran;
    $ch2 = curl_init($url2);
    # Setup request to send json via POST.
    $payload2 = json_encode(array(
        'nik' => $nik,
        'nama_lengkap' => $nama_lengkap,
        'nomor_hp' => $nomor_hp,
        'email' => $email,
        'password' => $password,
        'role' => "Pengguna",
        'saldo' => $sisa_saldo
    ));
    curl_setopt($ch2, CURLOPT_POSTFIELDS, $payload2);
    curl_setopt($ch2, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
    # Return response instead of printing.
    curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
    # Send request.
    $result2 = curl_exec($ch2);
    curl_close($ch2);
    $_SESSION['saldo'] = $sisa_saldo;

    $ch = curl_init($url);
    # Setup request to send json via POST.
    $payload = json_encode(array(
        'id_pemesanankoperasi' => $id_pemesanankoperasi,
        'nik' => $nik,
        'nama_pemesan' => $nama_pemesan,
        'tanggalpemesanan' => $tanggalpemesanan,
        'nama_produk' => $nama_produk,
        'harga_produk' => $harga_produk,
        'jumlah_produk' => $jumlah_produk,
        'jenis_pembayaran' => $jenis_pembayaran,
        'status_pembayaran' => $status_pembayaran
    ));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
    # Return response instead of printing.
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    # Send request.
    $result = curl_exec($ch);
    curl_close($ch);
    # Print response.
    header('Location: daftarpemesananKoperasi.php');
} else {
    echo "<script>alert('Gagal Membeli Produk Koperasi. Saldo tidak cukup!!!');window.location='daftarpemesananKoperasi.php'</script>";
}


?>