<?php
session_start();
$url = "http://127.0.0.1:8210/topupsaldo";
$content = file_get_contents($url);
$myjson = json_decode($content);

if (!isset($_SESSION['logged_in'])) {
    header('location:../login.php');
} else {
    $nik = $_SESSION['nik'];
    $nama_lengkap = $_SESSION['nama_lengkap'];
    $nomor_hp = $_SESSION['nomor_hp'];
    $email = $_SESSION['email'];
    $password = $_SESSION['password'];
    $role = $_SESSION['role'];
    $saldo = $_SESSION['saldo'];
}
?>
<?php include "header.php"; ?>

<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Top Up Saldo</h1>
    <p class="mb-4">Daftar Histori Top Up Saldo! <a href="topupSaldo.php"><button type="button" class="btn btn-primary float-right">Top Up Saldo</button></a></p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Daftar Histori Top Up Saldo <b>" Menunggu Konfirmasi "</b></h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Tanggal Top Up</th>
                            <th>NIK</th>
                            <th>Nama Lengkap</th>
                            <th>Nomor HP</th>
                            <th>Saldo Top Up</th>
                            <th>Status Top Up</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php for ($i = 0; $i < count($myjson); $i++) {
                            if ($myjson[$i]->nik == $nik && $myjson[$i]->status_topup == "Menunggu Konfirmasi") {
                                echo "<tr><td>" . $myjson[$i]->tanggal_topup . "</td>";
                                echo "<td>" . $myjson[$i]->nik . "</td>";
                                echo "<td>" . $myjson[$i]->nama_lengkap . "</td>";
                                echo "<td>" . $myjson[$i]->nomor_hp . "</td>";
                                echo "<td>" . $myjson[$i]->saldo_topup . "</td>";
                                echo "<td>" . $myjson[$i]->status_topup . "</td>";
                                echo '<td><a href="bataltopupSaldo.php?id_topup=' . $myjson[$i]->id_topup . '"class="badge badge-danger">Batal</a></td></tr>';
                            }
                        } ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Daftar Histori Top Up Saldo <b>" Berhasil "</b></h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Tanggal Top Up</th>
                            <th>NIK</th>
                            <th>Nama Lengkap</th>
                            <th>Nomor HP</th>
                            <th>Saldo Top Up</th>
                            <th>Status Top Up</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php for ($i = 0; $i < count($myjson); $i++) {
                            if ($myjson[$i]->nik == $nik && $myjson[$i]->status_topup == "Berhasil") {
                                echo "<tr><td>" . $myjson[$i]->tanggal_topup . "</td>";
                                echo "<td>" . $myjson[$i]->nik . "</td>";
                                echo "<td>" . $myjson[$i]->nama_lengkap . "</td>";
                                echo "<td>" . $myjson[$i]->nomor_hp . "</td>";
                                echo "<td>" . $myjson[$i]->saldo_topup . "</td>";
                                echo "<td>" . $myjson[$i]->status_topup . "</td>";
                            }
                        } ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<?php include "footer.php"; ?>