<?php
session_start();
$url = "http://127.0.0.1:8150/pemesananpulsa";
$content = file_get_contents($url);
$myjson = json_decode($content);

if (!isset($_SESSION['logged_in'])) {
    header('location:../login.php');
} else {
    $nik = $_SESSION['nik'];
    $nama_lengkap = $_SESSION['nama_lengkap'];
    $nomor_hp = $_SESSION['nomor_hp'];
    $email = $_SESSION['email'];
    $password = $_SESSION['password'];
    $role = $_SESSION['role'];
    $saldo = $_SESSION['saldo'];
}
?>
<?php include "header.php"; ?>

<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Pulsa Koperasi</h1>
    <p class="mb-4">Daftar Pemesanan Produk Pulsa Koperasi!</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Daftar Histori Pemesanan Produk Pulsa Koperasi <b>" Belum Lunas "</b></h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Tanggal Pemesanan</th>
                            <th>NIK</th>
                            <th>Nama Pemesan</th>
                            <th>Nomor Hp</th>
                            <th>Nama Produk</th>
                            <th>Harga Produk</th>
                            <th>Jenis Pembayaran</th>
                            <th>Status Pembayaran</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php for ($i = 0; $i < count($myjson); $i++) {
                            if ($myjson[$i]->nik == $nik && $myjson[$i]->status_pembayaran == "Belum Lunas") {
                                echo "<tr><td>" . $myjson[$i]->tanggalpemesanan . "</td>";
                                echo "<td>" . $myjson[$i]->nik . "</td>";
                                echo "<td>" . $myjson[$i]->nama_pemesan . "</td>";
                                echo "<td>" . $myjson[$i]->nomor_hp . "</td>";
                                echo "<td>" . $myjson[$i]->nama_produk . "</td>";
                                echo "<td>" . $myjson[$i]->harga_produk . "</td>";
                                echo "<td>" . $myjson[$i]->jenis_pembayaran . "</td>";
                                echo "<td>" . $myjson[$i]->status_pembayaran . "</td>";
                                if ($myjson[$i]->nik == $nik and $myjson[$i]->jenis_pembayaran == "Non-Tunai") {
                                    echo '<td> <a href="bayarpesananPulsa.php?id_pemesananpulsa=' . $myjson[$i]->id_pemesananpulsa . '"class="badge badge-success">Bayar</a> &nbsp &nbsp ';
                                    echo '<a href="batalpesananPulsa.php?id_pemesananpulsa=' . $myjson[$i]->id_pemesananpulsa . '"class="badge badge-danger">Batal</a>';
                                } else {
                                    echo "<td> Lakukan Pembayaran di kasir </td></tr>";
                                }
                            }
                        } ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Daftar Histori Pemesanan Produk Koperasi <b>" Lunas "</b></h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="pertama" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Tanggal Pemesanan</th>
                            <th>NIK</th>
                            <th>Nama Pemesan</th>
                            <th>Nomor Hp</th>
                            <th>Nama Produk</th>
                            <th>Harga Produk</th>
                            <th>Jenis Pembayaran</th>
                            <th>Status Pembayaran</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php for ($i = 0; $i < count($myjson); $i++) {
                            if ($myjson[$i]->nik == $nik && $myjson[$i]->status_pembayaran == "Lunas") {
                                echo "<tr><td>" . $myjson[$i]->tanggalpemesanan . "</td>";
                                echo "<td>" . $myjson[$i]->nik . "</td>";
                                echo "<td>" . $myjson[$i]->nama_pemesan . "</td>";
                                echo "<td>" . $myjson[$i]->nomor_hp . "</td>";
                                echo "<td>" . $myjson[$i]->nama_produk . "</td>";
                                echo "<td>" . $myjson[$i]->harga_produk . "</td>";
                                echo "<td>" . $myjson[$i]->jenis_pembayaran . "</td>";
                                echo "<td>" . $myjson[$i]->status_pembayaran . "</td>";
                            }
                        } ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<?php include "footer.php"; ?>