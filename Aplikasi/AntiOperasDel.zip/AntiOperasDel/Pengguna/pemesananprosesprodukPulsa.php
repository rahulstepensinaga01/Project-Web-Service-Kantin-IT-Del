
<?php
session_start();

$id_pemesananpulsa = $_POST["id_pemesananpulsa"];
$nik = $_POST["nik"];
$nama_pemesan = $_POST["nama_pemesan"];
$nomor_hp = $_POST["nomor_hp"];
$tanggalpemesanan = $_POST["tanggalpemesanan"];
$nama_produk = $_POST["nama_produk"];
$harga_produk = $_POST["harga_produk"];
$jenis_pembayaran = $_POST["jenis_pembayaran"];

$url = "http://localhost:8150/pemesananpulsa/";

$ch = curl_init($url);
# Setup request to send json via POST.
$payload = json_encode(array(
    'id_pemesananpulsa' => $id_pemesananpulsa,
    'nik' => $nik,
    'nama_pemesan' => $nama_pemesan,
    'nomor_hp' => $nomor_hp,
    'tanggalpemesanan' => $tanggalpemesanan,
    'nama_produk' => $nama_produk,
    'harga_produk' => $harga_produk,
    'jenis_pembayaran' => $jenis_pembayaran,
    'status_pembayaran' => "Belum Lunas"
));
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
# Return response instead of printing.
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
# Send request.
$result = curl_exec($ch);
curl_close($ch);
# Print response.
header('Location: daftarpemesananPulsa.php');

?>