<?php
session_start();
$url = "http://localhost:8090/pengguna";;
$content = file_get_contents($url);
$myjson = json_decode($content);

if (isset($_GET["nik"])) {
    $nik = $_GET["nik"];
    $url = "http://localhost:8090/pengguna" . $nik;
    $content = file_get_contents($url);
    $myjson = json_decode($content, true);
}

if (!isset($_SESSION['logged_in'])) {
    header('location:../login.php');
} else {
    $nik = $_SESSION['nik'];
    $nama_lengkap = $_SESSION['nama_lengkap'];
    $nomor_hp = $_SESSION['nomor_hp'];
    $email = $_SESSION['email'];
    $password = $_SESSION['password'];
    $role = $_SESSION['role'];
    $saldo = $_SESSION['saldo'];
}
for ($i = 0; $i < count($myjson); $i++) {
    if ($myjson[$i]->nik == $nik) {
        $nik1 = $myjson[$i]->nik;
        $nama_lengkap1 = $myjson[$i]->nama_lengkap;
        $nomor_hp1 = $myjson[$i]->nomor_hp;
        $email1 = $myjson[$i]->email;
        $role1 = $myjson[$i]->role;
        $saldo1 = $myjson[$i]->saldo;
        break;
    }
}
?>
<?php include "header.php"; ?>

<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Data Pribadi</h1>
    <p class="mb-4">Data Pribadi!</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Data Pribadi</h6>
        </div>
        <div class="card-body">
            <div class="form-group">
                <label for="nama_produk">Nik</label>
                <input type="number" class="form-control" id="nik" name="nik" placeholder="Masukkan Nama Produk..." value="<?php echo $nik ?>" readonly>
            </div>
            <div class="form-group">
                <label for="nama_produk">Nama Lengkap</label>
                <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap" placeholder="Masukkan Nama Pemesan..." value="<?php echo $nama_lengkap1 ?>" readonly>
            </div>
            <div class="form-group">
                <label for="nama_produk">Nomor HP</label>
                <input type="number" class="form-control" id="nomor_hp" name="nomor_hp" placeholder="Masukkan Nama Pemesan..." value="<?php echo $nomor_hp1 ?>" readonly>
            </div>
            <div class="form-group">
                <label for="nama_produk">Email</label>
                <input type="email" class="form-control" id="email" name="email" placeholder="Masukkan Nama Produk..." value="<?php echo $email1 ?>" readonly>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" id="password" name="password" placeholder="Masukkan Nama Produk..." value="<?php echo $password ?>" readonly>
            </div>
            <div class="form-group">
                <label for="role">Role</label>
                <input type="text" class="form-control" id="role" name="role" placeholder="Masukkan Nama Produk..." value="<?php echo $role1 ?>" readonly>
            </div>
            <div class="form-group">
                <label for="saldo">Saldo</label>
                <div class="input-group">
                    <input type="int" class="form-control" id="saldo" name="saldo" placeholder="Masukkan Nama Produk..." value="<?php echo $saldo1 ?>" readonly>
                    <div class="input-group-append">
                        <a href="topupSaldo.php"><button class="btn btn-primary" type="button"><i class="fas fa-plus"></i></button></a>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <a href="indexPengguna.php"><button type="button" class="btn btn-secondary float-left">Kembali</button></a>
                <a href="editProfil.php?nik=<?php echo $nik ?>"><button type="button" class="btn btn-primary float-right">Edit</button></a>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<?php include "footer.php"; ?>