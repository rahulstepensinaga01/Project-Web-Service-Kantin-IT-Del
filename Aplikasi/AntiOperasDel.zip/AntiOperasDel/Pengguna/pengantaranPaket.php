<?php
session_start();
$url = "http://127.0.0.1:8200/pengantaranpaket";
$content = file_get_contents($url);
$myjson = json_decode($content);

if (!isset($_SESSION['logged_in'])) {
    header('location:../login.php');
} else {
    $nik = $_SESSION['nik'];
    $nama_lengkap = $_SESSION['nama_lengkap'];
    $nomor_hp = $_SESSION['nomor_hp'];
    $email = $_SESSION['email'];
    $password = $_SESSION['password'];
    $role = $_SESSION['role'];
    $saldo = $_SESSION['saldo'];
}
?>
<?php include "header.php"; ?>

<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Pengantaran Paket</h1>
    <p class="mb-4">Daftar Pengantaran Paket!</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Daftar Pengantaran Paket <b>" Belum Diambil "</b></h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Nomor Resi Paket</th>
                            <th>NIK</th>
                            <th>Nama Penerima</th>
                            <th>Nama Pengirim</th>
                            <th>Nomor Telepon Pengirim</th>
                            <th>Nomor Telepon Penerima</th>
                            <th>Alamat Tujuan</th>
                            <th>Alamat Pengirim</th>
                            <th>Berat Paket</th>
                            <th>Tanggal Dikirim</th>
                            <th>Tanggal Diterima</th>
                            <th>Status Paket</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php for ($i = 0; $i < count($myjson); $i++) {
                            if ($myjson[$i]->nik == $nik && $myjson[$i]->status_paket == "Belum Diambil") {
                                echo "<tr><td>" . $myjson[$i]->no_resipaket . "</td>";
                                echo "<td>" . $myjson[$i]->nik . "</td>";
                                echo "<td>" . $myjson[$i]->nama_penerima . "</td>";
                                echo "<td>" . $myjson[$i]->nama_pengirim . "</td>";
                                echo "<td>" . $myjson[$i]->nomor_telepon_pengirim . "</td>";
                                echo "<td>" . $myjson[$i]->nomor_telepon_penerima . "</td>";
                                echo "<td>" . $myjson[$i]->alamat_tujuan . "</td>";
                                echo "<td>" . $myjson[$i]->alamat_pengirim . "</td>";
                                echo "<td>" . $myjson[$i]->berat_paket . "</td>";
                                echo "<td>" . $myjson[$i]->tanggal_dikirim . "</td>";
                                echo "<td>" . $myjson[$i]->tanggal_diterima . "</td>";
                                echo "<td>" . $myjson[$i]->status_paket . "</td>";
                                echo '<td> <a href="ambilpengantaranPaket.php?id_paket=' . $myjson[$i]->id_paket . '"class="badge badge-primary">Ambil</a> ';
                            }
                        } ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Daftar Pengantaran Paket <b>" Sudah Diambil "</b></h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="pertama" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Nomor Resi Paket</th>
                            <th>NIK</th>
                            <th>Nama Penerima</th>
                            <th>Nama Pengirim</th>
                            <th>Nomor Telepon Pengirim</th>
                            <th>Nomor Telepon Penerima</th>
                            <th>Alamat Tujuan</th>
                            <th>Alamat Pengirim</th>
                            <th>Berat Paket</th>
                            <th>Tanggal Dikirim</th>
                            <th>Tanggal Diterima</th>
                            <th>Status Paket</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php for ($i = 0; $i < count($myjson); $i++) {
                            if ($myjson[$i]->nik == $nik && $myjson[$i]->status_paket == "Sudah Diambil") {
                                echo "<tr><td>" . $myjson[$i]->no_resipaket . "</td>";
                                echo "<td>" . $myjson[$i]->nik . "</td>";
                                echo "<td>" . $myjson[$i]->nama_penerima . "</td>";
                                echo "<td>" . $myjson[$i]->nama_pengirim . "</td>";
                                echo "<td>" . $myjson[$i]->nomor_telepon_pengirim . "</td>";
                                echo "<td>" . $myjson[$i]->nomor_telepon_penerima . "</td>";
                                echo "<td>" . $myjson[$i]->alamat_tujuan . "</td>";
                                echo "<td>" . $myjson[$i]->alamat_pengirim . "</td>";
                                echo "<td>" . $myjson[$i]->berat_paket . "</td>";
                                echo "<td>" . $myjson[$i]->tanggal_dikirim . "</td>";
                                echo "<td>" . $myjson[$i]->tanggal_diterima . "</td>";
                                echo "<td>" . $myjson[$i]->status_paket . "</td></tr>";
                            }
                        } ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<?php include "footer.php"; ?>