<?php
session_start();
$url = "http://127.0.0.1:8180/pemesanankantin";
$content = file_get_contents($url);
$myjson = json_decode($content);

if (!isset($_SESSION['logged_in'])) {
    header('location:../login.php');
} else {
    $nik = $_SESSION['nik'];
    $nama_lengkap = $_SESSION['nama_lengkap'];
    $nomor_hp = $_SESSION['nomor_hp'];
    $email = $_SESSION['email'];
    $password = $_SESSION['password'];
    $role = $_SESSION['role'];
    $saldo = $_SESSION['saldo'];
}
?>
<?php include "header.php"; ?>

<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Pemesanan Produk Kantin</h1>
    <p class="mb-4">Daftar Pemesanan Produk Kantin!</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Daftar Histori Pemesanan Produk Kantin <b>" Belum Lunas "</b></h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Tanggal Pemesanan</th>
                            <th>NIK</th>
                            <th>Nama Pemesan</th>
                            <th>Nama Produk</th>
                            <th>Harga Produk</th>
                            <th>Jumlah Produk</th>
                            <th>Total Harga</th>
                            <th>Jenis Pembayaran</th>
                            <th>Status Pembayaran</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php for ($i = 0; $i < count($myjson); $i++) {
                            if ($myjson[$i]->nik == $nik && $myjson[$i]->status_pembayaran == "Belum Lunas") {
                                echo "<tr><td>" . $myjson[$i]->tanggalpemesanan . "</td>";
                                echo "<td>" . $myjson[$i]->nik . "</td>";
                                echo "<td>" . $myjson[$i]->nama_pemesan . "</td>";
                                echo "<td>" . $myjson[$i]->nama_produk . "</td>";
                                echo "<td>" . $myjson[$i]->harga_produk . "</td>";
                                echo "<td>" . $myjson[$i]->jumlah_produk . "</td>";
                                echo "<td>" . $myjson[$i]->harga_produk * $myjson[$i]->jumlah_produk . "</td>";
                                echo "<td>" . $myjson[$i]->jenis_pembayaran . "</td>";
                                echo "<td>" . $myjson[$i]->status_pembayaran . "</td>";
                                if ($myjson[$i]->nik == $nik && $myjson[$i]->jenis_pembayaran == "Non-Tunai") {
                                    echo '<td> <a href="bayarpesananKantin.php?id_pemesanankantin=' . $myjson[$i]->id_pemesanankantin . '"class="badge badge-success">Bayar</a> &nbsp &nbsp ';
                                    echo '<a href="batalpesananKantin.php?id_pemesanankantin=' . $myjson[$i]->id_pemesanankantin . '"class="badge badge-danger">Batal</a>';
                                } else {
                                    echo "<td> Lakukan Pembayaran di kasir </td></tr>";
                                }
                            }
                        } ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Daftar Histori Pemesanan Produk Kantin <b>" Lunas "</b></h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="pertama" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Tanggal Pemesanan</th>
                            <th>NIK</th>
                            <th>Nama Pemesan</th>
                            <th>Nama Produk</th>
                            <th>Harga Produk</th>
                            <th>Jumlah Produk</th>
                            <th>Total Harga</th>
                            <th>Jenis Pembayaran</th>
                            <th>Status Pembayaran</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php for ($i = 0; $i < count($myjson); $i++) {
                            if ($myjson[$i]->nik == $nik && $myjson[$i]->status_pembayaran == "Lunas") {
                                echo "<tr><td>" . $myjson[$i]->tanggalpemesanan . "</td>";
                                echo "<td>" . $myjson[$i]->nik . "</td>";
                                echo "<td>" . $myjson[$i]->nama_pemesan . "</td>";
                                echo "<td>" . $myjson[$i]->nama_produk . "</td>";
                                echo "<td>" . $myjson[$i]->harga_produk . "</td>";
                                echo "<td>" . $myjson[$i]->jumlah_produk . "</td>";
                                echo "<td>" . $myjson[$i]->harga_produk * $myjson[$i]->jumlah_produk . "</td>";
                                echo "<td>" . $myjson[$i]->jenis_pembayaran . "</td>";
                                echo "<td>" . $myjson[$i]->status_pembayaran . "</td>";
                            }
                        } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<?php include "footer.php"; ?>