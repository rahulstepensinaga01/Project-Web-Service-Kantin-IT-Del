<?php
session_start();
$url = "http://localhost:8170/ruangan/";
$content = file_get_contents($url);
$myjson = json_decode($content);

if (!isset($_SESSION['logged_in'])) {
    header('location:../login.php');
} else {
    $nik = $_SESSION['nik'];
    $nama_lengkap = $_SESSION['nama_lengkap'];
    $nomor_hp = $_SESSION['nomor_hp'];
    $email = $_SESSION['email'];
    $password = $_SESSION['password'];
    $role = $_SESSION['role'];
    $saldo = $_SESSION['saldo'];
}
$tanggalpemesanan = date("Y-m-d");
$id_ruangan = $_GET["id_ruangan"];
for ($i = 0; $i < count($myjson); $i++) {
    if ($myjson[$i]->id_ruangan == $id_ruangan) {
        $id_ruangan = $myjson[$i]->id_ruangan;
        $lokasi_ruangan = $myjson[$i]->lokasi_ruangan;
        $status_ruangan = $myjson[$i]->status_ruangan;
        break;
    }
}
?>
<?php include "header.php"; ?>

<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Ruangan</h1>
    <p class="mb-4">Pemesanan Ruangan!</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Pemesanan Ruangan</h6>
        </div>
        <div class="card-body">
            <form method="post" enctype="multipart/form-data" action="pemesananprosesRuangan.php">
                <div class="card-body">
                    <input type="number" class="form-control" id="id_pemesananruangan" name="id_pemesananruangan" hidden>
                    <input type="number" class="form-control" id="id_ruangan" name="id_ruangan" value="<?php echo $id_ruangan ?>" hidden>
                    <div class="form-group">
                        <label for="nama_produk">Nik</label>
                        <input type="text" class="form-control" id="nik" name="nik" placeholder="Masukkan Nama Produk..." value="<?php echo $nik; ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="nama_produk">Nama Pemesan</label>
                        <input type="text" class="form-control" id="nama_pemesan" name="nama_pemesan" placeholder="Masukkan Nama Pemesan..." value="<?php echo $nama_lengkap; ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="nama_produk">Tanggal Pemesan</label>
                        <input type="date" class="form-control" id="tanggalpemesanan" name="tanggalpemesanan" placeholder="Masukkan Tanggal Pemesan..." value="<?php echo $tanggalpemesanan; ?>" readonly>
                    </div>
                    <input type="text" class="form-control" id="status_ruangan" name="status_ruangan" placeholder="Masukkan Nama Produk..." value="Menunggu Approval" hidden>
                    <div class="form-group">
                        <label for="jenis_produk">Lokasi Ruangan</label>
                        <input type="text" class="form-control" id="lokasi_ruangan" name="lokasi_ruangan" placeholder="Masukkan Jenis Produk..." value="<?php echo $lokasi_ruangan; ?>" readonly>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="ruangan.php"><button type="button" class="btn btn-secondary float-left">Kembali</button></a>
                    <button type="submit" class="btn btn-primary float-right">Pesan</button>
                </div>
            </form>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<?php include "footer.php"; ?>