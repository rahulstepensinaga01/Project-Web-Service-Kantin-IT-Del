<?php
session_start();
$url = "http://localhost:8110/produkkantin/";
$content = file_get_contents($url);
$myjson = json_decode($content);

if (!isset($_SESSION['logged_in'])) {
    header('location:../login.php');
} else {
    $nik = $_SESSION['nik'];
    $nama_lengkap = $_SESSION['nama_lengkap'];
    $nomor_hp = $_SESSION['nomor_hp'];
    $email = $_SESSION['email'];
    $password = $_SESSION['password'];
    $role = $_SESSION['role'];
    $saldo = $_SESSION['saldo'];
}
$tanggalpemesanan = date("Y-m-d");
$id = $_GET["id"];
for ($i = 0; $i < count($myjson); $i++) {
    if ($myjson[$i]->id_produk == $id) {
        $id_produk = $myjson[$i]->id_produk;
        $nama_produk = $myjson[$i]->nama_produk;
        $jenis_produk = $myjson[$i]->jenis_produk;
        $harga_produk = $myjson[$i]->harga_produk;
        break;
    }
}
?>
<?php include "header.php"; ?>

<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Produk Kantin</h1>
    <p class="mb-4">Pemesanan Produk Kantin!</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Beli Produk Kantin</h6>
        </div>
        <div class="card-body">
            <form method="post" enctype="multipart/form-data" action="pemesananprosesprodukKantin.php">
                <div class="card-body">
                    <input type="number" class="form-control" id="id_pemesanankantin" name="id_pemesanankantin" hidden>
                    <div class="form-group">
                        <label for="nama_produk">Nik</label>
                        <input type="text" class="form-control" id="nik" name="nik" placeholder="Masukkan Nama Produk..." value="<?php echo $nik; ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="nama_produk">Nama Pemesan</label>
                        <input type="text" class="form-control" id="nama_pemesan" name="nama_pemesan" placeholder="Masukkan Nama Pemesan..." value="<?php echo $nama_lengkap; ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="nama_produk">Tanggal Pemesan</label>
                        <input type="date" class="form-control" id="tanggalpemesanan" name="tanggalpemesanan" placeholder="Masukkan Nama Pemesan..." value="<?php echo $tanggalpemesanan; ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="nama_produk">Nama Produk</label>
                        <input type="text" class="form-control" id="nama_produk" name="nama_produk" placeholder="Masukkan Nama Produk..." value="<?php echo $nama_produk; ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="jenis_produk">Jenis Produk</label>
                        <input type="text" class="form-control" id="jenis_produk" name="jenis_produk" placeholder="Masukkan Jenis Produk..." value="<?php echo $jenis_produk; ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="harga_produk">Harga Produk</label>
                        <input type="number" class="form-control" id="harga_produk" name="harga_produk" placeholder="Masukkan Harga Produk..." value="<?php echo $harga_produk; ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="jenis_produk">Jenis Pembayaran</label>
                        <select name="jenis_pembayaran" id="jenis_pembayaran" class="form-control form-group">
                            <option>
                                Tunai
                            </option>
                            <option>
                                Non-Tunai
                            </option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="harga_produk">Jumlah Produk</label>
                        <input type="number" class="form-control" id="jumlah_produk" name="jumlah_produk" placeholder="Masukkan JumlahProduk...">
                    </div>
                </div>
                <div class="card-footer">
                    <a href="produkKantin.php"><button type="button" class="btn btn-secondary float-left">Kembali</button></a>
                    <button type="submit" class="btn btn-primary float-right">Beli</button>
                </div>
            </form>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<?php include "footer.php"; ?>