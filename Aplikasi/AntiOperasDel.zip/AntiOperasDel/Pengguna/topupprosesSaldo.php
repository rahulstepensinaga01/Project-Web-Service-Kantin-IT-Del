
<?php
session_start();

$id_topup = $_POST["id_topup"];
$nik = $_POST["nik"];
$nama_lengkap = $_POST["nama_lengkap"];
$nomor_hp = $_POST["nomor_hp"];
$email = $_POST["email"];
$password = $_POST["password"];
$role = $_POST["role"];
$saldo = $_POST["saldo"];
$saldo_topup = $_POST["saldo_topup"];
$tanggal_topup = $_POST["tanggal_topup"];
$status_topup = $_POST["status_topup"];

$url = "http://localhost:8210/topupsaldo/";

$ch = curl_init($url);
# Setup request to send json via POST.
$payload = json_encode(array(
    'id_topup' => $id_topup,
    'nik' => $nik,
    'nama_lengkap' => $nama_lengkap,
    'nomor_hp' => $nomor_hp,
    'email' => $email,
    'password' => $password,
    'role' => $role,
    'saldo' => $saldo,
    'saldo_topup' => $saldo_topup,
    'tanggal_topup' => $tanggal_topup,
    'status_topup' => $status_topup
));

curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
# Return response instead of printing.
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
# Send request.
$result = curl_exec($ch);
curl_close($ch);
# Print response.
header('Location: daftartopupSaldo.php');


?>