<?php
session_start();
if (isset($_GET["nik"])) {
    $nik = $_GET["nik"];
    $url = "http://localhost:8090/pengguna/" . $nik;
    $content = file_get_contents($url);
    $myjson = json_decode($content, true);
}

if (!isset($_SESSION['logged_in'])) {
    header('location:../login.php');
} else {
    $nik = $_SESSION['nik'];
    $nama_lengkap = $_SESSION['nama_lengkap'];
    $nomor_hp = $_SESSION['nomor_hp'];
    $email = $_SESSION['email'];
    $password = $_SESSION['password'];
    $role = $_SESSION['role'];
    $saldo = $_SESSION['saldo'];
}
?>
<?php include "header.php"; ?>

<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Data Pribadi</h1>
    <p class="mb-4">Edit Data Pribadi!</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Data Pribadi</h6>
        </div>
        <div class="card-body">
            <form method="post" enctype="multipart/form-data" action="editprosesProfil.php">
                <div class="card-body">
                    <div class="form-group">
                        <label for="nama_produk">Nik</label>
                        <input type="text" class="form-control" id="nik" name="nik" placeholder="Masukkan NIK..." value="<?php echo $nik ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="nama_produk">Nama Lengkap</label>
                        <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap" placeholder="Masukkan Nama Lengkap..." value="<?php echo $myjson['nama_lengkap'] ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="nama_produk">Nomor HP</label>
                        <input type="text" class="form-control" id="nomor_hp" name="nomor_hp" placeholder="Masukkan Nomor HP..." value="<?php echo $myjson['nomor_hp'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="nama_produk">Email</label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Masukkan Email..." value="<?php echo $myjson['email'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Masukkan Password..." value="<?php echo $myjson['password'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="role">Role</label>
                        <input type="text" class="form-control" id="role" name="role" placeholder="Masukkan Role..." value="<?php echo $myjson['role'] ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="saldo">Saldo</label>
                        <input type="int" class="form-control" id="saldo" name="saldo" placeholder="Masukkan Saldo..." value="<?php echo $myjson['saldo'] ?>" readonly>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="profil.php"><button type="button" class="btn btn-secondary float-left">Kembali</button></a>
                    <button type="submit" class="btn btn-primary float-right">Edit</button>
                </div>
            </form>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<?php include "footer.php"; ?>