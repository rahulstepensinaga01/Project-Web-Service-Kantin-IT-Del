
<?php
session_start();

$nik = $_POST["nik"];
$nama_lengkap = $_POST["nama_lengkap"];
$nomor_hp = $_POST["nomor_hp"];
$email = $_POST["email"];
$password = $_POST["password"];

$url = "http://localhost:8090/pengguna/";

$ch = curl_init($url);
# Setup request to send json via POST.
$payload = json_encode(array(
    'nik' => $nik,
    'nama_lengkap' => $nama_lengkap,
    'nomor_hp' => $nomor_hp,
    'email' => $email,
    'password' => $password,
    'role' => "Pengguna",
    'saldo' => 0
));

curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
# Return response instead of printing.
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
# Send request.
$result = curl_exec($ch);
curl_close($ch);
# Print response.
header('Location: login.php');


?>